In addition to this file and the provided 'data' subdirectory, the subdirectory
'project' contains the a sample output database 'homes_sample.db,' and the
programs:

  - 'main.py'
  - 'parse_worker.py'
  - 'work_queue.py'
  - 'data_worker.py'

The file called `main.py` can be run through the command line from within the
'project' directory. It has two optional arguments that may be passed to it:
the name of the directory containing the data to be pushed to the database, and
whether the data should be parsed and stored in a temporary file ('parse'), or
should be parsed and stored in the database itself ('push').

To parse and push all of the data in the directory 'data' without producing any
temporary storage, run the command:

  '$ python3 main.py data push'

The program will produce a few lines of output in the terminal to let you know
that everything has run smoothly and that the data has been pushed to the
database successfully. It will additionally create logs ('stored_files.txt' and
stored_directories.txt) listing the files and directories whose data have been
pushed respectively.

Attempting to re-store data that has already been stored will elicit a simple
output in the terminal letting the user know as much, and the program will
terminate.

If the second flag is omitted, the program will assume that the data is to be
pushed to the database, so

  '$ python3 main.py data'

will produce the same results as the above command. Running the command

  '$ python3 main.py data parse'

will simply parse the data in the directory 'data' and store it in json files
which can be accessed at a later time. If this command is run and then the command

  '$python3 main.py data'

is run, the program will not re-parse the data, but will retrieve the previously
stored parsed data and push that to the database. The program's output will
specify whether the pushed data came directly from the parser or was accessed
from within a previously parsed file.

If the program is called with no flags:

  '$ python3 main.py'

it will ask for the name of a valid data directory and will again push the data
therein directly to the database with no intermediate storage created.

The program 'parse_worker.py' parses the data in a given directory and outputs
the data in dictionary form. The program 'work_queue.py' retrieves this parsed
data, either storing it in .json format or passing it directly to the program
'data_worker.py,' which accepts dictionaries of data and pushes them into the
database tables appropriately. Each of these programs contains comments for
further detail.

In the interest of clear testing, none of these programs delete used raw data
files or any temporary storage, but places where it may be appropriate to do so
have been commented on accordingly within.
