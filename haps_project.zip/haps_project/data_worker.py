import work_queue
import sqlite3
import os


### Fetches data from the work_queue and pushes it to the appropriate tables
### in the database
def data_push(data_directory):
	print('Fetching job from work queue...\n...\n...\n')
	### Call the work_queue to push the data from the given directory
	retrieved_job = work_queue.move_data('data', toggle='push')
	print('Parsed data received by data_worker.py, pushing to database...\n...\n...\n')
	
	### Locate the appropriate database (could be passed as an argument in a
	### more general setting)
	cwd = os.getcwd()
	db_file = cwd + '/data/homes.com/homes.db'
	
	### Function to format the data appropriately to be entered into the
	### database. This takes in a list of dictionaries and outputs a list of
	### tuples ordered according to the sql code which will insert them into
	### the database
	def push_sort(dict_list):
		sorted_tuples = []
		for dict in dict_list:
			temp_list = []
			key_sort = sorted(dict.keys())
			for key in key_sort:
				temp_list.append(dict[key])
			sorted_tuples.append(tuple(temp_list))
		return sorted_tuples
	
	### Run the reformatting function on the data retrieved from the work_queue
	agents_push = push_sort(retrieved_job['agents'])
	listings_push = push_sort(retrieved_job['listings'])
	offices_push = push_sort(retrieved_job['offices'])
	
	### Establish a connection to the database
	conn = sqlite3.connect(db_file)
	curs = conn.cursor()
	
	### Write the sql to input the data into each of the three tables
	agents_sql = '''INSERT INTO agents (agent_code, city, name, phone, state,
        zip) VALUES (?, ?, ?, ?, ?, ?)'''
	offices_sql = '''INSERT INTO offices (city, name, office_code, phone, state,
        zip) VALUES (?, ?, ?, ?, ?, ?)'''
	listings_sql = '''INSERT INTO listings (address, agent_id, city, description,
        mls_number, office_id, price, state, status, type, zip) VALUES (?, ?, ?,
        ?, ?, ?, ?, ?, ?, ?, ?)'''
	
	### Execute the insertion of the data
	curs.executemany(agents_sql, agents_push)
	curs.executemany(offices_sql, offices_push)
	curs.executemany(listings_sql, listings_push)
	
	### Commit changes to the database and close the connection
	conn.commit()
	curs.close()
	
	### Let the user know the data has been inserted successfully
	data_path = os.path.join(os.getcwd(), data_directory)
	print("Data from '%s' successfully pushed to database '%s'.\n"
	      % (data_path, db_file))
