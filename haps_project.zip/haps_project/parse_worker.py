import os
import csv
import json
import xml.etree.ElementTree as ET


### This program parses the raw data contained within a given directory. If the
### write argument is set to True, it will write the data into .json files.
def main1(data_directory, write=False):
	#### Create temporary storage if necessary
	if not os.path.exists('parsed_files') and write == True:
		os.makedirs('parsed_files')
	
	### Function to sort all data files within a directory by extension
	def sort_by_ext(data_directory):
		mls_directories = []
		file_dict = {'csv': [], 'xml': [], 'json': []}
		
		### Find all directories with mls data and add them to a list
		with os.scandir(data_directory) as contents:
			for entry in contents:
				if entry.is_dir() and 'mls' in entry.name:
					mls_directories.append('data/' + entry.name)
		
		### Search through all directories containing mls data and add the
		### filepaths therein to the appropriate list within the master dictionary
		for mls_directory in mls_directories:
			with os.scandir(mls_directory) as contents:
				for entry in contents:
					path = mls_directory + '/' + entry.name
					extn = entry.name.split('.')[1]
					file_dict[extn].append(path)
		### Returns a dictionary with extension types as keys and lists of all
		### files of each type as values
		return file_dict
	
	### Function to extract and parse data from .json files
	def json_extr(json_file_list, write=False):
		json_data = []
		for file in json_file_list:
			with open(file) as json_file:
				dict_list = json.load(json_file)
				for temp_dict in dict_list:
					new_dict = {key: val for key, val in temp_dict.items()
					            if key not in {'agent_phone', 'agent_name', 'office_phone',
					                           'office_name'}}
					new_dict['agent_id'] = new_dict.pop('agent_code')
					new_dict['office_id'] = new_dict.pop('office_code')
					new_dict['address'] = new_dict.pop('street_address')
					json_data.append(new_dict)
			if write:
				fwrite = 'parsed_files/' + file.replace('/', '_').replace('.', '_') + '.json'
				with open(fwrite, 'w') as fout:
					json.dump(json_data, fout)
		return json_data
	
	### Function to extract and parse data from .xml files
	def xml_extr(xml_file_list, write=False):
		xml_data = []
		for file in xml_file_list:
			tree = ET.parse(file)
			root = tree.getroot()
			for child in root:
				keys = []
				vals = []
				for item in child:
					if not list(item):
						keys.append(item.tag)
						vals.append(item.text)
					elif item.tag == 'broker':
						for sub_item in list(item):
							if sub_item.tag == 'code':
								keys.append('office_id')
								vals.append(sub_item.text)
					elif item.tag == 'address':
						for sub_item in list(item):
							if sub_item.tag != 'street':
								keys.append(sub_item.tag)
							else:
								keys.append(item.tag)
							vals.append(sub_item.text)
					else:
						for sub_item in list(item):
							if sub_item.tag == 'code':
								keys.append(item.tag + '_id')
								vals.append(sub_item.text)
				xml_data.append(dict(zip(keys, vals)))
			if write:
				fwrite = 'parsed_files/' + file.replace('/', '_').replace('.', '_') + '.json'
				with open(fwrite, 'w') as fout:
					json.dump(xml_data, fout)
		return xml_data
	
	### Function to extract and parse data from .csv files
	def csv_extr(csv_file_list, write=False):
		csv_data = {'listings': [], 'offices': [], 'agents': []}
		for file in csv_file_list:
			key = file.split('/')[-1].split('.')[0]
			with open(file) as csv_file:
				data_dict = csv.DictReader(csv_file)
				for row in data_dict:
					row_dict = dict(row)
					if key == 'listings':
						row_dict['office_id'] = row_dict.pop('OFFICE_CODE')
						row_dict['agent_id'] = row_dict.pop('AGENT_CODE')
						row_dict['description'] = row_dict.pop('DESC')
					elif key == 'agents':
						del row_dict['OFFICE_CODE']
					row_dict = {key.lower(): val for key, val in row_dict.items()}
					csv_data[key].append(row_dict)
			if write:
				fwrite = 'parsed_files/' + file.replace('/', '_').replace('.', '_') + '.json'
				with open(fwrite, 'w') as fout:
					json.dump(csv_data[key], fout)
		return csv_data
	
	### Sort the files within the given directory according to extentsion
	data_path = os.path.join(os.getcwd(), data_directory)
	file_dict = sort_by_ext(data_path)
	
	### Use the appropriate function to extract and parse the data from each
	json_listings = json_extr(file_dict['json'], write=write)
	xml_listings = xml_extr(file_dict['xml'], write=write)
	csv_data = csv_extr(file_dict['csv'], write=write)
	
	### Compile lists of the extracted data according to database tables
	listings = json_listings + xml_listings + csv_data['listings']
	agents = csv_data['agents']
	offices = csv_data['offices']
	
	### Returns a dictionary whose keys are the database table categories and
	### whose values are lists of dictionaries to be inserted into the tables
	
	### Could delete/move raw data and log parse job history here
	return {'listings': listings, 'agents': agents,
	        'offices': offices}
