import os
import sys

import data_worker
import work_queue

cwd = os.getcwd()
db_path = cwd+'/homes.com/db'

try:
    data_directory = sys.argv[1]
except:
    data_directory = input("\nPlease enter a data directory: ")

data_path = os.path.join(cwd, data_directory)
dirs = [file.path for file in os.scandir(cwd) if file.is_dir()]

if data_path not in dirs:
    print("\nError: The directory %s does not exist\n" %data_path)
    sys.exit()

try:
     fin = open('stored_directories.txt')
     stored_directories = fin.readlines()
except:
    stored_directories = []

try:
    toggle = sys.argv[2]
except:
    toggle = 'push'

def push_to_database(data_directory):
    print('Alerting data_worker.py of the job...\n...\n...\n')

    data_worker.data_push(data_directory)

    return None

def push_to_work_queue(data_directory):

    work_queue.move_data('data', toggle='fetch')

    store_path = cwd+'/'+'parsed_files'
    print('Data successfully parsed. Parsed data is stored in %s.\n' %store_path)
    return None

if data_path+'\n' in stored_directories:
    print("\nThe data from the directory %s is already in the database.\n" %data_path)


elif toggle == 'parse':
    print('\nAttempting to parse raw data files in the directory %s...\n...\n...\n' %data_path)
    push_to_work_queue(data_directory)

elif toggle == 'push':
    print('\nAttemping to push data from the directory %s into the database %s...\n...\n...\n' %(data_path, db_path))
    push_to_database(data_directory)

    data_directory = os.path.join(cwd,data_directory)
    fout = open('stored_directories.txt', 'a')
    fout.write('%s\n' %data_directory)
    fout.close()
    fout = open('stored_files.txt', 'a')
    data_directory = os.path.join(cwd,data_directory)
    with os.scandir(data_directory) as contents:
        for entry in contents:
            if entry.is_dir() and 'mls' in entry.name:
                full_path = os.path.join(data_directory,entry.name)
                with os.scandir(entry) as subcontents:
                    for subentry in subcontents:
                        full_path = os.path.join(full_path, subentry.name)
                        fout.write('%s\n' %full_path)
    fout.close()
