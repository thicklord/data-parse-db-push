import parse_worker
import json
import os

### Takes in parsed data from a given directory, either moving it to .json
### files for later use, or passing it directly to the data_worker.
def move_data(data_directory, toggle='push'):

    ### Checks if the given directory has already been parsed and stored or not
    def file_sort(data_directory):
        files_dict = {'parsed':[], 'unparsed':[]}
        if os.path.exists('parsed_files'):
            with os.scandir('parsed_files') as stored_jobs:
                for entry in stored_jobs:
                    if entry.name.split('.')[-1] == 'json':
                        files_dict['parsed'].append(entry.name)

        with os.scandir(data_directory) as contents:
            for entry in contents:
                if entry.is_dir() and 'mls' in entry.name:
                    with os.scandir(entry) as subcontents:
                        for subentry in subcontents:
                            file = data_directory+'_'+ entry.name+'_'+subentry.name.replace('.','_') + '.json'
                            if file not in files_dict['parsed']:
                                files_dict['unparsed'].append(file)

        ### Returns a dictionary containing the files from the directory,
        ### grouping them according to whether or not they have been parsed yet
        return files_dict


    ### Function to push parsed data to the data_worker
    def push_to_data_worker(data_directory):
        push_dict = {'listings':[], 'offices':[], 'agents':[]}
        ### If the requested data has already been parsed, retrieve it from
        ### the temporary storage
        if not file_sort(data_directory)['unparsed']:
            for file in file_sort(data_directory)['parsed']:
                with open('parsed_files/' + file) as json_file:
                    data = json.load(json_file)
                    tags = data[0].keys()
                    if 'price' in tags:
                        key = 'listings'
                    elif 'agent_code' in tags:
                        key = 'agents'
                    else:
                        key = 'offices'
                for row in data:
                    push_dict[key].append(row)
            print("Data successfully pulled from stored parsed jobs...\n...\n...\n")
            ### Could delete/move temporary storage and log job history here
            return push_dict

        ### If the data is not parsed and stored, retrieve it directly by
        ### calling the parse_worker
        else:
            print("Requesting data directly from parse_worker.py...\n...\n...\n")
            return fetch_from_parse_worker(data_directory, write=False)


    ### Function to fetch parsed data from the parse_worker
    def fetch_from_parse_worker(data_directory, write=True):
        print('Sending directory information to parse_worker.py...\n...\n...\n')
        ### Call the parse_worker, passing the flag for it to write to temporary
        ### storage
        return parse_worker.main1(data_directory, write=write)


    ### If the user wishes to push parsed data into the database
    if toggle == 'push':
        return push_to_data_worker(data_directory)
    ### If the user only wishes to fetch and store parsed data
    if toggle == 'fetch':
        return fetch_from_parse_worker(data_directory)
